let a = 5
let b = 20

document.getElementById("h1").innerHTML= a+b;
console.log("<br>");
document.getElementById("h1").innerHTML= a*b;