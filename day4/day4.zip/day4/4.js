let a=5
a++

document.getElementById("h1").innerText = a