let a = 5
let b = 4
let c = 6
let d = 3

let ans = a>b && b>c && c<d && d<a;

document.getElementById("h1").innerText = ans;