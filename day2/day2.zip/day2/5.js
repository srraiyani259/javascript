
document.getElementById("h1").innerHTML="Hello! New Box"