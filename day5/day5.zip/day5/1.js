let a = document.getElementById("i1").value
let b = document.getElementById("i2").value
let c = document.getElementById("i3").value
let d = document.getElementById("i4").value
let e = document.getElementById("i5").value

document.getElementById("box-1").innerText = a;
document.getElementById("box-2").innerText = b;
document.getElementById("box-3").innerText = c;
document.getElementById("box-4").innerText = d;
document.getElementById("box-5").innerText = e;

document.getElementById("box1").innerText = d;
document.getElementById("box2").innerText = b;
document.getElementById("box3").innerText = e;
document.getElementById("box4").innerText = c;
document.getElementById("box5").innerText = a;