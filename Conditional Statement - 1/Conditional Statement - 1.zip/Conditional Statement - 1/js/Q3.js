let a = document.getElementById('in').value

switch(a){
case 'red' : console.log("Please stop")
break;
case 'yellow' : console.log("Slow down")
break;
case 'green' : console.log("go!!!!!")
break;
default:console.log("invalid light color")

}